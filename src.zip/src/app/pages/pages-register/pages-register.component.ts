import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pages-register',
  templateUrl: './pages-register.component.html',
  styleUrls: ['./pages-register.component.css']
})
export class PagesRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
