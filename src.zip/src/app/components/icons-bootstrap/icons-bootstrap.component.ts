import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-icons-bootstrap',
  templateUrl: './icons-bootstrap.component.html',
  styleUrls: ['./icons-bootstrap.component.css']
})
export class IconsBootstrapComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
