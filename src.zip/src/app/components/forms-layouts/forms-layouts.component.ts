import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forms-layouts',
  templateUrl: './forms-layouts.component.html',
  styleUrls: ['./forms-layouts.component.css']
})
export class FormsLayoutsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
