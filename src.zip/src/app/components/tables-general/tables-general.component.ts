import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tables-general',
  templateUrl: './tables-general.component.html',
  styleUrls: ['./tables-general.component.css']
})
export class TablesGeneralComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
